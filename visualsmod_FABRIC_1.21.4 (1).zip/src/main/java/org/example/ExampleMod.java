
package org.example;

import net.fabricmc.api.ModInitializer;

public class ExampleMod implements ModInitializer {
    @Override
    public void onInitialize() {
        System.out.println("VisualsMod loaded!");
    }
}
