
package org.example;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.minecraft.particle.ParticleTypes;

public class ClientInit implements ClientModInitializer {

    @Override
    public void onInitializeClient() {

        ClientTickEvents.END_CLIENT_TICK.register(client -> {

            if (client.player == null || client.world == null) return;

            // simple aura particles
            if (client.player.age % 2 == 0) {

                double x = client.player.getX();
                double y = client.player.getY() + 1.0;
                double z = client.player.getZ();

                double radius = 0.8;

                for (int i = 0; i < 8; i++) {
                    double angle = (System.currentTimeMillis() / 50.0 + i * 45) * Math.PI / 180;

                    double px = x + Math.cos(angle) * radius;
                    double pz = z + Math.sin(angle) * radius;

                    client.world.addParticle(
                            ParticleTypes.END_ROD,
                            px, y, pz,
                            0, 0.02, 0
                    );
                }
            }
        });
    }
}
